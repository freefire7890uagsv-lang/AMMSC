
export interface Student {
  id: string;
  serialNo: number;
  name: string;
  isPresent: boolean;
  absenceReason?: string;
}

export interface ClassData {
  className: string;
  classTeacherName: string;
  students: Student[];
  teacherRemarks: string;
  chairmanRemarks: string;
}

export interface AppState {
  schoolName: string;
  teacherName: string;
  reportDate: string;
  chairmanAnnouncement: string;
  schoolLogo?: string; // Base64 string of the uploaded logo
  classes: Record<string, ClassData>;
}

export const CLASS_IDS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'];
