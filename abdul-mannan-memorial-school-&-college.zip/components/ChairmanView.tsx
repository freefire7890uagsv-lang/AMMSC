
import React from 'react';
import { Megaphone, MessageSquare, ShieldCheck, Info } from 'lucide-react';

interface ChairmanViewProps {
  announcement: string;
  onUpdate: (val: string) => void;
}

const ChairmanView: React.FC<ChairmanViewProps> = ({ announcement, onUpdate }) => {
  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 pb-8 border-b border-slate-100">
        <div className="w-full md:max-w-2xl space-y-2">
          <h2 className="text-4xl font-black text-slate-900 leading-none flex items-center gap-4">
            <Megaphone className="w-10 h-10 text-orange-500" />
            Chairman's Notice Board
          </h2>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-widest ml-1">
            Global announcement for all teachers and staff
          </p>
        </div>
      </div>

      <div className="bg-orange-50 rounded-[3rem] p-8 md:p-12 border-2 border-orange-100 shadow-xl shadow-orange-50">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center gap-3">
            <div className="bg-orange-600 p-2.5 rounded-xl shadow-lg shadow-orange-200">
              <MessageSquare className="text-white w-6 h-6" />
            </div>
            <h3 className="text-xl font-black text-slate-800">Post an Announcement</h3>
          </div>

          <textarea
            value={announcement}
            onChange={(e) => onUpdate(e.target.value)}
            placeholder="Type the announcement here for all teachers to see..."
            rows={10}
            className="w-full p-8 rounded-[2.5rem] border-2 border-white bg-white/80 backdrop-blur-sm text-lg font-bold text-slate-800 focus:ring-8 focus:ring-orange-200/50 focus:border-orange-500 focus:outline-none transition-all shadow-inner"
          />

          <div className="flex items-center gap-4 px-4 py-3 bg-white/50 rounded-2xl border border-white">
            <Info className="w-5 h-5 text-orange-500" />
            <p className="text-xs font-bold text-slate-500 italic">
              Note: This message will be displayed prominently on the Home dashboard for every teacher to see.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="p-8 bg-white border-2 border-slate-100 rounded-[2rem] flex items-start gap-4">
          <div className="bg-indigo-100 p-3 rounded-2xl">
            <ShieldCheck className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h4 className="font-black text-slate-800">Official Communication</h4>
            <p className="text-sm font-bold text-slate-400 mt-1">
              Direct and transparent channel between the Chairman and the teaching staff.
            </p>
          </div>
        </div>
        <div className="p-8 bg-white border-2 border-slate-100 rounded-[2rem] flex items-start gap-4">
          <div className="bg-emerald-100 p-3 rounded-2xl">
            <Megaphone className="w-6 h-6 text-emerald-600" />
          </div>
          <div>
            <h4 className="font-black text-slate-800">Instant Visibility</h4>
            <p className="text-sm font-bold text-slate-400 mt-1">
              Announcements are updated in real-time across the platform.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChairmanView;
