
import React from 'react';
import { LayoutDashboard, Users, ArrowRight, BookOpen, Clock, ShieldCheck, GraduationCap, Megaphone } from 'lucide-react';
import { AppState, CLASS_IDS, ClassData } from '../types';

interface HomeProps {
  state: AppState;
  onSelectClass: (id: string) => void;
}

const Home: React.FC<HomeProps> = ({ state, onSelectClass }) => {
  // Fix: Explicitly type 'cls' as ClassData to allow access to the 'students' property
  const totalStudents = Object.values(state.classes).reduce(
    (sum, cls: ClassData) => sum + cls.students.length, 
    0
  );

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Hero Welcome Section */}
      <div className="relative overflow-hidden bg-indigo-700 rounded-[3rem] p-8 md:p-12 text-white shadow-2xl shadow-indigo-200">
        <div className="relative z-10 max-w-2xl">
          <h2 className="text-3xl md:text-5xl font-black mb-4 leading-tight">
            Welcome, <span className="text-indigo-200">{state.teacherName}</span>
          </h2>
          <p className="text-indigo-100 text-lg font-medium mb-8 leading-relaxed">
            This is the official digital attendance portal of <span className="font-bold underline decoration-indigo-400 underline-offset-4">{state.schoolName}</span>. Select a class below to manage your student records.
          </p>
          <div className="flex flex-wrap gap-4">
            <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 flex items-center gap-3">
              <Users className="w-5 h-5 text-indigo-300" />
              <span className="font-bold">Total Students: {totalStudents}</span>
            </div>
            <div className="bg-white/10 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 flex items-center gap-3">
              <Clock className="w-5 h-5 text-indigo-300" />
              <span className="font-bold">Date: {new Date(state.reportDate).toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-60 h-60 bg-indigo-500/20 rounded-full blur-2xl"></div>
        
        {state.schoolLogo ? (
          <img 
            src={state.schoolLogo} 
            alt="School Logo Overlay" 
            className="absolute right-12 bottom-12 w-48 h-48 object-contain opacity-20 rotate-12 hidden lg:block" 
          />
        ) : (
          <GraduationCap className="absolute right-12 bottom-12 w-48 h-48 text-white/5 rotate-12 hidden lg:block" />
        )}
      </div>

      {/* Notice Board Area */}
      {state.chairmanAnnouncement && (
        <div className="bg-orange-50 border-2 border-orange-100 rounded-[2.5rem] p-8 flex flex-col md:flex-row items-start gap-6 shadow-xl shadow-orange-50/50">
          <div className="bg-orange-600 p-4 rounded-2xl shadow-lg shadow-orange-200 shrink-0">
            <Megaphone className="w-8 h-8 text-white animate-bounce" />
          </div>
          <div className="flex-1 space-y-2">
            <h4 className="text-xs font-black text-orange-600 uppercase tracking-[0.2em]">Chairman's Important Notice</h4>
            <div className="text-lg font-bold text-slate-800 leading-relaxed whitespace-pre-wrap">
              {state.chairmanAnnouncement}
            </div>
          </div>
        </div>
      )}

      {/* Quick Access Grid */}
      <div className="space-y-6">
        <div className="flex items-center gap-3 px-2">
          <LayoutDashboard className="w-6 h-6 text-indigo-600" />
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">Class Dashboard</h3>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 sm:gap-6">
          {CLASS_IDS.map((id) => (
            <button
              key={id}
              onClick={() => onSelectClass(id)}
              className="group relative bg-white p-6 rounded-[2rem] border-2 border-slate-100 shadow-sm hover:shadow-xl hover:border-indigo-400 hover:-translate-y-1 transition-all duration-300 text-left"
            >
              <div className="bg-indigo-50 group-hover:bg-indigo-600 w-12 h-12 rounded-2xl flex items-center justify-center mb-4 transition-colors overflow-hidden">
                {state.schoolLogo ? (
                  <img src={state.schoolLogo} alt="Logo" className="w-8 h-8 object-contain transition-all group-hover:brightness-0 group-hover:invert" />
                ) : (
                  <BookOpen className="w-6 h-6 text-indigo-600 group-hover:text-white transition-colors" />
                )}
              </div>
              <h4 className="text-xl font-black text-slate-800">Class {id}</h4>
              <p className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-wider group-hover:text-indigo-400">Manage Attendance</p>
              <div className="absolute right-6 bottom-6 opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all">
                <ArrowRight className="w-5 h-5 text-indigo-600" />
              </div>
            </button>
          ))}

          {/* Chairman Box */}
          <button
            onClick={() => onSelectClass('chairman')}
            className="group relative bg-orange-600 p-6 rounded-[2rem] border-2 border-orange-500 shadow-xl shadow-orange-100 hover:bg-orange-700 hover:-translate-y-1 transition-all duration-300 text-left text-white"
          >
            <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center mb-4">
              <Megaphone className="w-6 h-6 text-white" />
            </div>
            <h4 className="text-xl font-black">Chairman</h4>
            <p className="text-xs font-bold text-orange-100 mt-1 uppercase tracking-wider">Post Notice</p>
            <div className="absolute right-6 bottom-6 opacity-0 group-hover:opacity-100 transform translate-x-2 group-hover:translate-x-0 transition-all">
              <ArrowRight className="w-5 h-5 text-white" />
            </div>
          </button>
        </div>
      </div>

      {/* Quick Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-6">
        <div className="bg-emerald-50 p-8 rounded-[2rem] border border-emerald-100">
          <ShieldCheck className="w-10 h-10 text-emerald-600 mb-4" />
          <h5 className="text-lg font-black text-emerald-900 mb-2">Secure Local Storage</h5>
          <p className="text-sm font-bold text-emerald-700/70 leading-relaxed">
            Data remains on your device for privacy. No cloud account required for daily records.
          </p>
        </div>
        <div className="bg-blue-50 p-8 rounded-[2rem] border border-blue-100">
          <Clock className="w-10 h-10 text-blue-600 mb-4" />
          <h5 className="text-lg font-black text-blue-900 mb-2">Efficient Flow</h5>
          <p className="text-sm font-bold text-blue-700/70 leading-relaxed">
            Auto-calculates total presence based on your absence entries, saving time every morning.
          </p>
        </div>
        <div className="bg-purple-50 p-8 rounded-[2rem] border border-purple-100">
          <BookOpen className="w-10 h-10 text-purple-600 mb-4" />
          <h5 className="text-lg font-black text-purple-900 mb-2">Excel Reports</h5>
          <p className="text-sm font-bold text-purple-700/70 leading-relaxed">
            Generate one master Excel file containing attendance data for all 10 classes in seconds.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;
