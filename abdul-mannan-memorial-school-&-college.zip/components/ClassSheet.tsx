
import React, { useState } from 'react';
import { Plus, Trash2, UserPlus, Users, UserMinus, UserCheck, MessageSquare, Info, AlertCircle, ChevronDown, UserX } from 'lucide-react';
import { ClassData, Student } from '../types';

interface ClassSheetProps {
  classId: string;
  classData: ClassData;
  onUpdateData: (updated: Partial<ClassData>) => void;
}

const ClassSheet: React.FC<ClassSheetProps> = ({ classId, classData, onUpdateData }) => {
  const [newStudentName, setNewStudentName] = useState('');
  const [showAbsentSelector, setShowAbsentSelector] = useState(false);

  const addStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim()) return;

    const newStudent: Student = {
      id: `${classId}-${Date.now()}`,
      serialNo: classData.students.length + 1,
      name: newStudentName.trim(),
      isPresent: true,
      absenceReason: '',
    };

    onUpdateData({ students: [...classData.students, newStudent] });
    setNewStudentName('');
  };

  const removeStudentFromMaster = (studentId: string) => {
    if (!confirm("Are you sure you want to permanently remove this student from the registry?")) return;
    const filtered = classData.students.filter(s => s.id !== studentId);
    const reindexed = filtered.map((s, index) => ({ ...s, serialNo: index + 1 }));
    onUpdateData({ students: reindexed });
  };

  const markAsAbsent = (studentId: string) => {
    const updatedStudents = classData.students.map(s => 
      s.id === studentId ? { ...s, isPresent: false } : s
    );
    onUpdateData({ students: updatedStudents });
    setShowAbsentSelector(false);
  };

  const markAsPresent = (studentId: string) => {
    const updatedStudents = classData.students.map(s => 
      s.id === studentId ? { ...s, isPresent: true, absenceReason: '' } : s
    );
    onUpdateData({ students: updatedStudents });
  };

  const updateReason = (studentId: string, reason: string) => {
    const updatedStudents = classData.students.map(s => 
      s.id === studentId ? { ...s, absenceReason: reason } : s
    );
    onUpdateData({ students: updatedStudents });
  };

  const absentStudents = classData.students.filter(s => !s.isPresent);
  const presentStudents = classData.students.filter(s => s.isPresent);
  const availableToMarkAbsent = classData.students.filter(s => s.isPresent);

  return (
    <div className="space-y-10">
      {/* Header: Class Teacher */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 pb-8 border-b border-slate-100">
        <div className="w-full md:max-w-md space-y-2">
          <label className="block text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Class Teacher Name</label>
          <div className="relative group">
            <UserCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Enter teacher name..."
              value={classData.classTeacherName || ''}
              onChange={(e) => onUpdateData({ classTeacherName: e.target.value })}
              className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold text-slate-800 focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all shadow-sm"
            />
          </div>
        </div>
        <div className="text-right">
          <h2 className="text-5xl font-black text-slate-900 leading-none">Class {classId}</h2>
        </div>
      </div>

      {/* The 3 Main Boxes */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Box 1: Total Students (Master Registry) */}
        <div className="flex flex-col h-[600px] bg-white rounded-[2rem] border-2 border-indigo-100 shadow-xl shadow-indigo-50 overflow-hidden">
          <div className="bg-indigo-600 p-6 text-white">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black uppercase tracking-widest bg-indigo-500 px-2 py-1 rounded-md">Box 1: Total Students</span>
              <Users className="w-6 h-6 opacity-40" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black">{classData.students.length}</span>
              <span className="text-indigo-200 text-sm font-bold">Registry</span>
            </div>
          </div>
          <div className="p-6 flex-1 flex flex-col space-y-6">
            <form onSubmit={addStudent} className="flex gap-2">
              <input
                type="text"
                placeholder="Add new student..."
                value={newStudentName}
                onChange={(e) => setNewStudentName(e.target.value)}
                className="flex-1 bg-slate-50 border border-slate-200 px-4 py-2.5 rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <button type="submit" className="bg-indigo-600 text-white p-2.5 rounded-xl hover:bg-indigo-700 transition-all shadow-md active:scale-95">
                <UserPlus className="w-5 h-5" />
              </button>
            </form>
            <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
              {classData.students.map(s => (
                <div key={s.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl group border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/30 transition-all">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-indigo-300 uppercase leading-none mb-1">ID #{s.serialNo}</span>
                    <span className="text-sm font-black text-slate-700">{s.name}</span>
                  </div>
                  <button 
                    onClick={() => removeStudentFromMaster(s.id)} 
                    className="text-slate-300 hover:text-red-500 p-2 transition-colors"
                    title="Remove permanently"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {classData.students.length === 0 && (
                <div className="py-20 text-center opacity-30 grayscale">
                  <UserPlus className="w-12 h-12 mx-auto mb-3" />
                  <p className="text-xs font-black">No students in registry</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Box 2: Absent Students (Selection) */}
        <div className="flex flex-col h-[600px] bg-white rounded-[2rem] border-2 border-red-100 shadow-xl shadow-red-50 overflow-hidden">
          <div className="bg-red-600 p-6 text-white">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black uppercase tracking-widest bg-red-500 px-2 py-1 rounded-md">Box 2: Absent Students</span>
              <UserMinus className="w-6 h-6 opacity-40" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black">{absentStudents.length}</span>
              <span className="text-red-200 text-sm font-bold">Selected</span>
            </div>
          </div>
          <div className="p-6 flex-1 flex flex-col space-y-6 bg-red-50/20">
            {/* Absent Selector Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setShowAbsentSelector(!showAbsentSelector)}
                className="w-full bg-white border-2 border-red-100 px-4 py-3 rounded-xl flex justify-between items-center shadow-sm hover:border-red-300 transition-all"
              >
                <span className="text-sm font-black text-red-600">Select to mark absent</span>
                <ChevronDown className={`w-5 h-5 text-red-400 transition-transform ${showAbsentSelector ? 'rotate-180' : ''}`} />
              </button>
              
              {showAbsentSelector && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl z-20 max-h-60 overflow-y-auto p-2">
                  {availableToMarkAbsent.length === 0 ? (
                    <p className="p-4 text-center text-xs text-slate-400 italic">No students available</p>
                  ) : (
                    availableToMarkAbsent.map(s => (
                      <button
                        key={s.id}
                        onClick={() => markAsAbsent(s.id)}
                        className="w-full text-left p-3 hover:bg-red-50 rounded-xl transition-colors text-sm font-bold text-slate-700 flex justify-between items-center"
                      >
                        {s.name}
                        <Plus className="w-4 h-4 text-red-400" />
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
              {absentStudents.length === 0 ? (
                <div className="py-20 text-center opacity-30 grayscale">
                  <UserX className="w-12 h-12 mx-auto mb-3" />
                  <p className="text-xs font-black">No students marked absent</p>
                </div>
              ) : (
                absentStudents.map(s => (
                  <div key={s.id} className="bg-white border-2 border-red-50 p-4 rounded-2xl shadow-sm space-y-3 relative group">
                    <div className="flex justify-between items-start">
                      <div className="flex flex-col">
                        <span className="text-[10px] font-black text-red-400 uppercase leading-none mb-1">Absent</span>
                        <span className="text-sm font-black text-slate-800">{s.name}</span>
                      </div>
                      <button 
                        onClick={() => markAsPresent(s.id)}
                        className="p-1.5 text-slate-300 hover:text-green-600 transition-colors"
                        title="Mark as Present"
                      >
                        <UserCheck className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="relative">
                      <MessageSquare className="absolute left-3 top-1/2 -translate-y-1/2 text-red-300 w-3.5 h-3.5" />
                      <input
                        type="text"
                        placeholder="Reason for absence..."
                        value={s.absenceReason || ''}
                        onChange={(e) => updateReason(s.id, e.target.value)}
                        className="w-full pl-9 pr-3 py-2 bg-red-50/50 border border-red-100 rounded-lg text-xs font-bold text-red-900 focus:ring-2 focus:ring-red-400 outline-none"
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Box 3: Present Students (Auto) */}
        <div className="flex flex-col h-[600px] bg-white rounded-[2rem] border-2 border-green-100 shadow-xl shadow-green-50 overflow-hidden">
          <div className="bg-green-600 p-6 text-white">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black uppercase tracking-widest bg-green-500 px-2 py-1 rounded-md">Box 3: Present Students</span>
              <UserCheck className="w-6 h-6 opacity-40" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-black">{presentStudents.length}</span>
              <span className="text-green-200 text-sm font-bold">Auto-calculated</span>
            </div>
          </div>
          <div className="p-6 flex-1 flex flex-col space-y-3 bg-green-50/20">
            <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
              {presentStudents.map(s => (
                <div key={s.id} className="flex items-center gap-3 p-4 bg-white border border-green-100 rounded-2xl shadow-sm">
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500 shadow-lg shadow-green-200"></div>
                  <span className="text-sm font-black text-slate-700">{s.name}</span>
                </div>
              ))}
              {presentStudents.length === 0 && classData.students.length > 0 && (
                <div className="py-20 text-center opacity-30">
                  <AlertCircle className="w-12 h-12 mx-auto mb-3" />
                  <p className="text-xs font-black italic">Everyone is absent!</p>
                </div>
              )}
              {classData.students.length === 0 && (
                <div className="py-20 text-center opacity-20">
                  <p className="text-xs font-black">List is empty</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Remarks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
        <div className="space-y-4">
          <label className="flex items-center gap-3 text-sm font-black text-slate-700 uppercase tracking-widest">
            <div className="bg-indigo-100 p-2 rounded-lg">
              <MessageSquare className="w-4 h-4 text-indigo-600" />
            </div>
            Class Teacher's Remarks
          </label>
          <textarea
            value={classData.teacherRemarks}
            onChange={(e) => onUpdateData({ teacherRemarks: e.target.value })}
            placeholder="Enter teacher comments here..."
            rows={5}
            className="w-full p-5 rounded-3xl border-2 border-slate-100 bg-white text-sm font-bold text-slate-800 focus:ring-8 focus:ring-indigo-50/50 focus:border-indigo-500 focus:outline-none transition-all shadow-lg shadow-slate-100/50"
          />
        </div>

        <div className="space-y-4">
          <label className="flex items-center gap-3 text-sm font-black text-slate-700 uppercase tracking-widest">
            <div className="bg-emerald-100 p-2 rounded-lg">
              <Info className="w-4 h-4 text-emerald-600" />
            </div>
            Chairman's Remarks
          </label>
          <textarea
            value={classData.chairmanRemarks}
            onChange={(e) => onUpdateData({ chairmanRemarks: e.target.value })}
            placeholder="Enter Chairman's official comments here..."
            rows={5}
            className="w-full p-5 rounded-3xl border-2 border-slate-100 bg-white text-sm font-bold text-slate-800 focus:ring-8 focus:ring-emerald-50/50 focus:border-emerald-500 focus:outline-none transition-all shadow-lg shadow-slate-100/50"
          />
        </div>
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #e2e8f0;
          border-radius: 20px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #cbd5e1;
        }
      `}</style>
    </div>
  );
};

export default ClassSheet;
