
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User, FileDown, GraduationCap, Check, X, Edit2, Calendar, Home as HomeIcon, Megaphone, Smartphone, Camera, Save } from 'lucide-react';
import { AppState, ClassData, CLASS_IDS } from './types';
import ClassSheet from './components/ClassSheet';
import Home from './components/Home';
import ChairmanView from './components/ChairmanView';

// Fix: Declaring XLSX as a global constant to resolve "Cannot find name 'XLSX'" errors
declare const XLSX: any;

const STORAGE_KEY = 'mannan_memorial_attendance_v2';

const initialData: AppState = {
  schoolName: 'Abdul Mannan Memorial School & College',
  teacherName: "Teacher's Name",
  reportDate: new Date().toISOString().split('T')[0],
  chairmanAnnouncement: '',
  schoolLogo: '', 
  classes: CLASS_IDS.reduce((acc, id) => {
    acc[id] = {
      className: `Class ${id}`,
      classTeacherName: '',
      students: [],
      teacherRemarks: '',
      chairmanRemarks: '',
    };
    return acc;
  }, {} as Record<string, ClassData>),
};

const SplashScreen = ({ logo, schoolName }: { logo?: string; schoolName: string }) => (
  <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-indigo-600 animate-in fade-in duration-500">
    <div className="relative">
      <div className="absolute inset-0 bg-white/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="relative bg-white p-6 rounded-[2.5rem] shadow-2xl animate-bounce overflow-hidden flex items-center justify-center w-32 h-32 md:w-40 md:h-40">
        {logo ? (
          <img src={logo} alt="School Logo" className="w-full h-full object-contain" />
        ) : (
          <GraduationCap className="w-16 h-16 md:w-20 md:h-20 text-indigo-600" />
        )}
      </div>
    </div>
    <div className="mt-8 text-center animate-in slide-in-from-bottom-4 duration-1000 px-6">
      <h1 className="text-2xl md:text-3xl font-black text-white tracking-tight drop-shadow-lg">
        {schoolName}
      </h1>
      <p className="text-indigo-100 text-xs font-bold mt-2 uppercase tracking-[0.3em] opacity-80">Digital Attendance Portal</p>
      <div className="mt-6 flex gap-1.5 justify-center">
        <div className="w-2.5 h-2.5 bg-white/40 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2.5 h-2.5 bg-white/60 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2.5 h-2.5 bg-white rounded-full animate-bounce"></div>
      </div>
    </div>
  </div>
);

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [state, setState] = useState<AppState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : initialData;
    } catch (e) {
      console.error("Error loading state:", e);
      return initialData;
    }
  });
  
  const [activeClassId, setActiveClassId] = useState<string | 'home' | 'chairman'>('home');
  const [isEditingTeacher, setIsEditingTeacher] = useState(false);
  const [isEditingSchool, setIsEditingSchool] = useState(false);
  const [tempTeacherName, setTempTeacherName] = useState(state.teacherName);
  const [tempSchoolName, setTempSchoolName] = useState(state.schoolName);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Splash Screen Timer
  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  // Save state to LocalStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    
    // Briefly show a "saved" status if needed
    setSaveStatus('saving');
    const timer = setTimeout(() => setSaveStatus('idle'), 1000);
    return () => clearTimeout(timer);
  }, [state]);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    }
  };

  const updateTeacherName = () => {
    setState(prev => ({ ...prev, teacherName: tempTeacherName }));
    setIsEditingTeacher(false);
  };

  const updateSchoolName = () => {
    setState(prev => ({ ...prev, schoolName: tempSchoolName }));
    setIsEditingSchool(false);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (limit to 2MB for localStorage safety)
      if (file.size > 2 * 1024 * 1024) {
        alert("Logo file is too large! Please select an image under 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setState(prev => ({ ...prev, schoolLogo: base64String }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdateClassData = useCallback((id: string, updatedData: Partial<ClassData>) => {
    setState(prev => ({
      ...prev,
      classes: {
        ...prev.classes,
        [id]: { ...prev.classes[id], ...updatedData }
      }
    }));
  }, []);

  const handleExportExcel = () => {
    if (typeof XLSX === 'undefined') {
      alert('Excel library not loaded yet.');
      return;
    }
    const wb = XLSX.utils.book_new();
    // Fix: Explicitly type 'cls' as ClassData to resolve unknown type errors when accessing properties
    Object.values(state.classes).forEach((cls: ClassData) => {
      const dataRows = cls.students.map(s => ({
        'Serial No': s.serialNo,
        'Student Name': s.name,
        'Attendance': s.isPresent ? 'Present' : 'Absent',
        'Reason of Absence': s.absenceReason || '-'
      }));
      const summaryData = [
        {},
        { 'Serial No': 'SUMMARY', 'Student Name': cls.className },
        { 'Serial No': 'Date', 'Student Name': state.reportDate },
        { 'Serial No': 'Total Students', 'Student Name': cls.students.length },
        { 'Serial No': 'Present', 'Student Name': cls.students.filter(s => s.isPresent).length },
        { 'Serial No': 'Absent', 'Student Name': cls.students.filter(s => !s.isPresent).length },
        { 'Serial No': 'Remarks', 'Student Name': cls.teacherRemarks || 'None' }
      ];
      const ws = XLSX.utils.json_to_sheet([...dataRows, ...summaryData]);
      XLSX.utils.book_append_sheet(wb, ws, cls.className);
    });
    XLSX.writeFile(wb, `${state.schoolName}_${state.reportDate}.xlsx`);
  };

  if (showSplash) {
    return <SplashScreen logo={state.schoolLogo} schoolName={state.schoolName} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f2f5] animate-in fade-in duration-1000">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center py-4 md:h-24 gap-4">
            
            {/* Logo and School Name Section */}
            <div className="flex items-center gap-4">
              <div className="relative group">
                <div 
                  className="bg-indigo-600 w-14 h-14 rounded-2xl shadow-xl shadow-indigo-100 cursor-pointer overflow-hidden flex items-center justify-center border-2 border-indigo-50 hover:border-indigo-300 transition-all active:scale-95" 
                  onClick={() => setActiveClassId('home')}
                >
                  {state.schoolLogo ? (
                    <img src={state.schoolLogo} alt="School Logo" className="w-full h-full object-cover" />
                  ) : (
                    <GraduationCap className="text-white w-8 h-8" />
                  )}
                </div>
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 bg-white p-1.5 rounded-full shadow-lg border border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity z-10 hover:bg-slate-50"
                  title="Upload Permanent Logo"
                >
                  <Camera className="w-3.5 h-3.5 text-indigo-600" />
                </button>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleLogoUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
              </div>
              
              <div className="flex flex-col">
                {isEditingSchool ? (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={tempSchoolName}
                      onChange={(e) => setTempSchoolName(e.target.value)}
                      className="bg-slate-50 border-2 border-indigo-200 outline-none text-xl font-black px-3 py-1.5 rounded-xl text-slate-900 shadow-inner"
                      autoFocus
                    />
                    <button onClick={updateSchoolName} className="p-2 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors shadow-md"><Check className="w-5 h-5" /></button>
                    <button onClick={() => setIsEditingSchool(false)} className="p-2 bg-slate-200 text-slate-600 rounded-xl hover:bg-slate-300 transition-colors"><X className="w-5 h-5" /></button>
                  </div>
                ) : (
                  <div className="flex items-center group cursor-pointer" onClick={() => setIsEditingSchool(true)}>
                    <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight leading-tight">{state.schoolName}</h1>
                    <Edit2 className="w-4 h-4 ml-3 text-slate-300 opacity-0 group-hover:opacity-100 transition-all transform group-hover:scale-110" />
                  </div>
                )}
                <div className="flex items-center gap-2 mt-0.5">
                  <p className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em]">Digital Attendance Hub</p>
                  {saveStatus === 'saving' && <span className="text-[10px] font-bold text-slate-400 animate-pulse flex items-center gap-1"><Save className="w-2.5 h-2.5" /> Saving...</span>}
                </div>
              </div>
            </div>

            {/* Controls Section */}
            <div className="flex flex-wrap justify-center items-center gap-3">
              <div className="flex items-center bg-white border-2 border-slate-100 px-4 py-2 rounded-2xl shadow-sm focus-within:border-indigo-300 transition-colors">
                <Calendar className="w-4 h-4 text-indigo-500 mr-2.5" />
                <input
                  type="date"
                  value={state.reportDate}
                  onChange={(e) => setState(prev => ({ ...prev, reportDate: e.target.value }))}
                  className="bg-transparent border-none outline-none text-sm font-black text-slate-700 cursor-pointer"
                />
              </div>

              <div className="flex items-center bg-white px-4 py-2 rounded-2xl border-2 border-slate-100 shadow-sm">
                <User className="w-4 h-4 text-slate-400 mr-2.5" />
                {isEditingTeacher ? (
                  <div className="flex items-center gap-1">
                    <input
                      type="text"
                      value={tempTeacherName}
                      onChange={(e) => setTempTeacherName(e.target.value)}
                      className="bg-transparent border-none outline-none text-sm font-bold w-28 text-slate-900 focus:ring-0"
                      autoFocus
                    />
                    <button onClick={updateTeacherName} className="text-green-600 p-1"><Check className="w-4 h-4" /></button>
                  </div>
                ) : (
                  <div className="flex items-center cursor-pointer group" onClick={() => setIsEditingTeacher(true)}>
                    <span className="text-sm font-bold text-slate-700 mr-2">{state.teacherName}</span>
                    <Edit2 className="w-3.5 h-3.5 text-slate-300 group-hover:text-indigo-500 transition-colors" />
                  </div>
                )}
              </div>
              
              <button
                onClick={handleExportExcel}
                className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-2xl text-sm font-black transition-all shadow-lg shadow-indigo-100 active:scale-95"
              >
                <FileDown className="w-4 h-4" />
                Export Data
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 md:py-10">
        <div className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/60 border border-slate-100 overflow-hidden flex flex-col min-h-[700px]">
          
          {/* Tabs Navigation */}
          <div className="bg-slate-50/80 backdrop-blur-sm border-b border-slate-200 overflow-x-auto">
            <nav className="flex whitespace-nowrap px-6">
              <button
                onClick={() => setActiveClassId('home')}
                className={`flex items-center gap-2 px-8 py-6 text-sm font-black transition-all border-b-4 ${activeClassId === 'home' ? 'border-indigo-600 text-indigo-600 bg-white' : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}`}
              >
                <HomeIcon className="w-4 h-4" /> Home
              </button>
              {CLASS_IDS.map((id) => (
                <button
                  key={id}
                  onClick={() => setActiveClassId(id)}
                  className={`px-8 py-6 text-sm font-black transition-all border-b-4 ${activeClassId === id ? 'border-indigo-600 text-indigo-600 bg-white' : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}`}
                >
                  Class {id}
                </button>
              ))}
              <button
                onClick={() => setActiveClassId('chairman')}
                className={`flex items-center gap-2 px-8 py-6 text-sm font-black transition-all border-b-4 ${activeClassId === 'chairman' ? 'border-orange-500 text-orange-600 bg-white' : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-100/50'}`}
              >
                <Megaphone className="w-4 h-4" /> Chairman
              </button>
            </nav>
          </div>

          {/* Content Area */}
          <div className="p-6 md:p-12 flex-1 overflow-y-auto">
            {activeClassId === 'home' ? (
              <Home state={state} onSelectClass={setActiveClassId} />
            ) : activeClassId === 'chairman' ? (
              <ChairmanView 
                announcement={state.chairmanAnnouncement} 
                onUpdate={(val) => setState(prev => ({ ...prev, chairmanAnnouncement: val }))} 
              />
            ) : (
              <ClassSheet
                classId={activeClassId}
                classData={state.classes[activeClassId]}
                onUpdateData={(updated) => handleUpdateClassData(activeClassId, updated)}
              />
            )}
          </div>
        </div>
      </main>

      <footer className="bg-white border-t border-slate-200 py-10 text-center">
        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center gap-3 opacity-30 grayscale hover:grayscale-0 transition-all duration-500">
            {state.schoolLogo ? (
               <img src={state.schoolLogo} alt="Logo" className="w-8 h-8 object-contain" />
            ) : (
               <GraduationCap className="w-8 h-8 text-slate-600" />
            )}
            <span className="font-black text-slate-800 tracking-tighter text-lg">{state.schoolName}</span>
          </div>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.4em]">
            &copy; {new Date().getFullYear()} - Professional Attendance Management System
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
